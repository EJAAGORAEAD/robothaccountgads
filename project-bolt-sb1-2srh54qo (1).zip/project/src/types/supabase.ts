export interface SubAccount {
  id: string;
  customer_id: string;
  name: string;
  status: string;
  user_id: string;
  descriptive_name?: string;
  currency_code: string;
  time_zone: string;
  organization_name?: string;
  legal_name?: string;
  address?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  is_advertising_agency: boolean;
  payment_mode?: string;
  created_at: string;
  updated_at: string;
}

export interface Campaign {
  id: string;
  name: string;
  status: string;
  budget: number;
  start_date: string;
  end_date?: string;
  type: string;
  sub_account_id: string;
  created_at: string;
  updated_at: string;
}

export interface CreditCard {
  id: string;
  sub_account_id: string;
  card_number_hash: string;
  expiration_date: string;
  card_holder_name: string;
  created_at: string;
  updated_at: string;
}

export interface Advertisement {
  id: string;
  campaign_id: string;
  name: string;
  final_url: string;
  video_id?: string;
  headline?: string;
  description?: string;
  created_at: string;
  updated_at: string;
}