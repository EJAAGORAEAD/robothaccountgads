import { useEffect, useState } from 'react'
import { Card, Title, Text } from '@tremor/react'
import { useNavigate } from 'react-router-dom'
import { Auth } from '@supabase/auth-ui-react'
import { ThemeSupa } from '@supabase/auth-ui-shared'
import { supabase } from '@/lib/supabase'

export default function Home() {
  const navigate = useNavigate()
  const [redirectUrl, setRedirectUrl] = useState('')

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setRedirectUrl(`${window.location.origin}/dashboard`)
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) {
        navigate('/dashboard')
      }
    })

    return () => subscription.unsubscribe()
  }, [navigate])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <Card className="max-w-lg w-full">
        <Title>Automação Google Ads</Title>
        <Text className="mt-4">Entre com sua conta para acessar o sistema</Text>
        <div className="mt-6">
          <Auth
            supabaseClient={supabase}
            appearance={{ 
              theme: ThemeSupa,
              variables: {
                default: {
                  colors: {
                    brand: '#2563eb',
                    brandAccent: '#1d4ed8',
                  },
                },
              },
            }}
            providers={['google']}
            redirectTo={redirectUrl}
          />
        </div>
      </Card>
    </div>
  )
}