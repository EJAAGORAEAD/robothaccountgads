import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { createClient } from '@supabase/supabase-js'
import Home from './pages'
import Dashboard from './pages/dashboard'
import Subcontas from './pages/dashboard/subcontas'
import NovaSubconta from './pages/dashboard/subcontas/nova'

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
)

function App() {
  const [user, setUser] = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null)
    })

    return () => subscription.unsubscribe()
  }, [])

  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to="/dashboard" /> : <Home />} />
      <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/" />} />
      <Route path="/dashboard/subcontas" element={user ? <Subcontas /> : <Navigate to="/" />} />
      <Route path="/dashboard/subcontas/nova" element={user ? <NovaSubconta /> : <Navigate to="/" />} />
    </Routes>
  )
}

export default App