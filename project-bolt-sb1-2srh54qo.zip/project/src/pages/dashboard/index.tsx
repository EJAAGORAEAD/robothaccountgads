import { useEffect, useState } from 'react';
import { Card, Title, Text, Button, Grid } from '@tremor/react';
import { useRouter } from 'next/router';
import { createClient } from '@supabase/supabase-js';

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        router.push('/');
      } else {
        setUser(session.user);
      }
    });
  }, [router]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex justify-between items-center mb-8">
          <div>
            <Title>Painel de Controle</Title>
            <Text>Gerencie suas contas e campanhas do Google Ads</Text>
          </div>
          <Button onClick={handleSignOut}>Sair</Button>
        </div>

        <Grid numItems={1} numItemsSm={2} numItemsLg={3} className="gap-6">
          <Card className="space-y-4">
            <div>
              <Title>Subcontas</Title>
              <Text>Gerencie suas subcontas do Google Ads</Text>
            </div>
            <Button onClick={() => router.push('/dashboard/subcontas')}>
              Ver Subcontas
            </Button>
          </Card>

          <Card className="space-y-4">
            <div>
              <Title>Campanhas</Title>
              <Text>Visualize e gerencie suas campanhas</Text>
            </div>
            <Button onClick={() => router.push('/dashboard/campanhas')}>
              Ver Campanhas
            </Button>
          </Card>

          <Card className="space-y-4">
            <div>
              <Title>Relatórios</Title>
              <Text>Analise o desempenho das suas campanhas</Text>
            </div>
            <Button onClick={() => router.push('/dashboard/relatorios')}>
              Ver Relatórios
            </Button>
          </Card>
        </Grid>
      </div>
    </div>
  );
}